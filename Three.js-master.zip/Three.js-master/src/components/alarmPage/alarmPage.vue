<template>
  <div>传感器详情界面</div>
</template>

<script>
    export default {
        name: "alarmPage"
    }
</script>

<style scoped>

</style>
